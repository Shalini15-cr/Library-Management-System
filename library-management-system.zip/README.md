# 📚 BIBLIOTECH: Library Management System
### *A Production-Ready Full-Stack Python Flask & MongoDB Engineering Project*

Welcome to **Bibliotech**, a complete, high-performance, and responsive **Library Management System** engineered to replace manual library registers with a secure digital database ledger. 

This project is fully designed and structured as a **Final Year Engineering Project**, incorporating clean modular components, dual-role access control, precise transaction state models, and structured log audits.

---

## 🏗️ System Architecture & Stack

Bibliotech utilizes an architectural design separating data layer persistence, controller dispatch routes, and elegant reactive views.

- **Frontend Core**: HTML5, Tailwind CSS, JavaScript (Vanilla ES6), Lucide Icon Packs.
- **Backend Core**: Python 3 (Flask Microframework v2.3+).
- **Database Layer**: MongoDB (NoSQL Document Store) accessed via the official **PyMongo** driver.
- **State Engine**: Atomic transitions of book statuses: `Available` ➡️ `Requested` (Pending Approval) ➡️ `Issued` ➡️ `Returned` (Available).

---

## 📂 Project Structure

```text
Library-Management-System/
│
├── app.py                     # Main Python Flask Controller and Entry Point
├── config.py                  # Environment-aware Configuration Registry
├── requirements.txt           # Python Dependency Registry
├── README.md                  # Comprehensive Documentation & Setup Guide
│
├── database/                  # Database Layer
│   └── db.py                  # PyMongo Database Connector & Connection Pool
│
├── models/                    # Data Access & Business Logic Layer
│   ├── student.py             # Student Model & Registration Handler
│   ├── admin.py               # Admin/Librarian Authentication Model
│   ├── book.py                # Book Catalog CRUD & Search Model
│   └── transaction.py         # Request, Issue, Return & Audit Ledger Model
│
├── templates/                 # Jinja2 HTML Layout Templates
│   ├── index.html             # High-Contrast Home Landing Page
│   ├── student_login.html     # Student Authentication View
│   ├── student_dashboard.html # Student Catalog & Request Portal
│   ├── admin_login.html       # Librarian Login Portal
│   ├── admin_dashboard.html   # Admin Inventory & Approval Dashboard
│   ├── book_details.html      # Detailed Book View & Review Log
│   ├── transaction_history.html# Full Transaction Audit Log
│   └── search_result.html     # Book Search Matcher & Fallback Screen
│
└── static/                    # Custom CSS & JavaScript Assets
    ├── css/
    │   ├── style.css          # Landing page custom styles
    │   ├── dashboard.css      # Dashboard layout styling
    │   └── login.css          # Login card overlays
    └── js/
        ├── script.js          # Interactive notifications and UI handlers
        └── search.js          # Dynamic live query filter helper
```

---

## 🗄️ MongoDB Collections & Schema Design

Bibliotech maintains five highly optimized document collections:

1. **`students`**: Records of registered students on campus.
   ```json
   {
     "_id": "ObjectId",
     "student_id": "CS2026105",
     "student_name": "John Doe",
     "department": "Computer Science & Engineering",
     "last_login": "YYYY-MM-DD HH:MM:SS"
   }
   ```
2. **`admins`**: Secured administrative credentials for staff/librarians.
   ```json
   {
     "_id": "ObjectId",
     "username": "admin",
     "password": "admin123",
     "name": "Head Librarian"
   }
   ```
3. **`books`**: Master indexing vault catalog.
   ```json
   {
     "_id": "ObjectId",
     "title": "Atomic Habits",
     "author": "James Clear",
     "category": "Motivation",
     "review": "Builds positive habits and consistency.",
     "status": "Available | Requested | Issued",
     "image_url": "/static/images/book4.jpg"
   }
   ```
4. **`requests`**: Tracking requests pending staff authorization.
   ```json
   {
     "_id": "ObjectId",
     "student_id": "CS2026105",
     "student_name": "John Doe",
     "department": "Computer Science & Engineering",
     "book_id": "book4",
     "book_title": "Atomic Habits",
     "request_date": "YYYY-MM-DD HH:MM:SS",
     "status": "Pending | Approved | Rejected"
   }
   ```
5. **`transactions`**: Legal log audit trail ledger.
   ```json
   {
     "_id": "ObjectId",
     "student_id": "CS2026105",
     "student_name": "John Doe",
     "department": "Computer Science & Engineering",
     "book_id": "book4",
     "book_title": "Atomic Habits",
     "issue_date": "YYYY-MM-DD HH:MM:SS",
     "return_date": "N/A | YYYY-MM-DD HH:MM:SS",
     "status": "Issued | Returned"
   }
   ```

---

## 🚀 Local Setup & Execution Guide (Visual Studio Code)

Follow these direct steps to run this project locally on your machine inside **VS Code**:

### Prerequisites
1. Install **Python 3.10+** (Ensure you check "Add Python to PATH" during installation).
2. Install **MongoDB Community Server** locally or create a free sandbox cluster at [MongoDB Atlas](https://www.mongodb.com/atlas).
3. Install **Visual Studio Code** along with the **Python Extension** by Microsoft.

---

### Step 1: Open Project in VS Code
Open your project folder inside VS Code. Ensure the directory matches the structure above.

### Step 2: Set Up Python Virtual Environment
Open the VS Code Terminal (`Ctrl + ~` or `Cmd + ~`) and execute:
```bash
# Create virtual environment
python -m venv venv

# Activate Environment (Windows CMD)
venv\Scripts\activate

# Activate Environment (Windows PowerShell)
venv\Scripts\Activate.ps1

# Activate Environment (macOS/Linux)
source venv/bin/activate
```

### Step 3: Install Dependencies
With the virtual environment active, run pip installer:
```bash
pip install -r requirements.txt
```

### Step 4: Configure Environment Variables
Create a `.env` file in the project root:
```env
SECRET_KEY="your_custom_secure_secret_key_string"
MONGO_URI="mongodb://localhost:27017/"
DB_NAME="library_db"
FLASK_ENV="development"
```

### Step 5: Execute Application
Launch the Flask development server:
```bash
python app.py
```
Open your browser and navigate to **`http://localhost:3000`**!

---

## 🌐 Deployment Guide

### Database: MongoDB Atlas
1. Create a free cluster on [MongoDB Atlas](https://www.mongodb.com/atlas).
2. Go to **Network Access** and add IP `0.0.0.0/0` (Allow access from anywhere).
3. Go to **Database Access** and create a user with read/write permissions.
4. Copy your connection string (e.g., `mongodb+srv://<username>:<password>@cluster0.mongodb.net/?retryWrites=true&w=majority`).

### Backend Deployment: Render or Railway
1. Push your repository to **GitHub**.
2. Connect your repository to **Render** (as a Web Service) or **Railway**.
3. Set the **Build Command**: `pip install -r requirements.txt`
4. Set the **Start Command**: `gunicorn app:app` (or `python app.py`)
5. Add Environment Variables in Render/Railway dashboard:
   - `MONGO_URI`: Your MongoDB Atlas URI
   - `DB_NAME`: `library_db`
   - `SECRET_KEY`: `a_strong_random_secret_key`

---

## 📷 Screenshots Placeholder

```text
[Landing Page] -> Displays Hero banner, live book count stats, and login pathways.
[Student Dashboard] -> Book cards, search bar, and request tracking panel.
[Librarian Dashboard] -> Stats counter cards, book inventory CRUD, pending approval list.
[Transaction History] -> Complete audit ledger with student details, check-out and return times.
```

---

## 🔮 Future Enhancements

- 📱 QR Code / Barcode Scanning for instant book return verification.
- 🔔 Email / SMS overdue notifications for pending book returns.
- 📊 Advanced analytical charts showing monthly reading trends by department.

---

## 📄 License

This project is open-source and licensed under the **MIT License**.

---
*Bibliotech Library Management System - Developed with premium visual layout and structural precision.*
