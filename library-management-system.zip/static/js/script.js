// BIBLIOTECH Library System Front-end Logic utilities
document.addEventListener('DOMContentLoaded', () => {
    console.log('[INFO] Bibliotech dynamic client script loaded.');

    // Auto fadeout flash alerts after 5 seconds
    const alerts = document.querySelectorAll('[role="alert"]');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.5s ease-out, transform 0.5s ease-out';
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-10px)';
            setTimeout(() => alert.remove(), 500);
        }, 5000);
    });

    // Form confirmation helpers
    const deleteLinks = document.querySelectorAll('a[onclick*="confirm"]');
    deleteLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            const confirmed = confirm('Are you sure you want to proceed with this deletion? This state modification is irreversible in MongoDB.');
            if (!confirmed) {
                e.preventDefault();
            }
        });
    });
});
