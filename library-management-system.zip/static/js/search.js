// Search filter helpers
document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.querySelector('input[name="q"]');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            // Can be expanded to filter elements inline or suggest database titles
            const val = e.target.value.toLowerCase().trim();
            console.log(`[SEARCH] Filtering query sequence: ${val}`);
        });
    }
});
