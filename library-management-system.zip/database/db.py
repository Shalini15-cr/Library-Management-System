import os
from pymongo import MongoClient
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class Database:
    """
    MongoDB Database Connection Handler.
    Encapsulates PyMongo connection management and fallback handling.
    """
    _instance = None
    client = None
    db = None
    is_connected = False

    @classmethod
    def get_db(cls):
        """Returns active database connection instance."""
        if cls.db is None:
            cls.connect()
        return cls.db

    @classmethod
    def connect(cls):
        """Initialize connection to MongoDB."""
        mongo_uri = os.environ.get('MONGO_URI', 'mongodb://localhost:27017/')
        db_name = os.environ.get('DB_NAME', 'library_db')

        try:
            cls.client = MongoClient(mongo_uri, serverSelectionTimeoutMS=2000)
            cls.db = cls.client[db_name]
            # Ping database to confirm live connection
            cls.client.server_info()
            cls.is_connected = True
            print(f"[INFO] MongoDB connected successfully to database: {db_name}")
        except Exception as e:
            print(f"[WARNING] Mongo connection fallback mode: {e}")
            cls.is_connected = False
            cls.db = None

    @classmethod
    def get_collection(cls, collection_name):
        """Utility method to get a specific collection."""
        db = cls.get_db()
        if db is not None:
            return db[collection_name]
        return None
