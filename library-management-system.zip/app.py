"""
Library Management System - Flask Entry Point
Suitable as a Final Year Engineering Project.
Author: Senior Python Full Stack Developer & Software Architect
"""

import os
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, session
from pymongo import MongoClient
from bson.objectid import ObjectId
from config import Config

# Import modular database & models
from database.db import Database
from models.student import StudentModel
from models.admin import AdminModel
from models.book import BookModel
from models.transaction import TransactionModel

# Initialize Flask App
app = Flask(__name__, template_folder='templates', static_folder='static')
app.config.from_object(Config)

# Initialize MongoDB Connection
try:
    # Attempt to connect to MongoDB
    client = MongoClient(app.config['MONGO_URI'], serverSelectionTimeoutMS=2000)
    db = client[app.config['DB_NAME']]
    # Simple ping to verify connection
    client.server_info()
    mongo_connected = True
    print("[INFO] MongoDB connected successfully.")
except Exception as e:
    print(f"[WARNING] Could not connect to real MongoDB: {e}")
    print("[WARNING] Application will fall back to local in-memory DB or display warning in app.")
    mongo_connected = False
    db = None

# Default book collection to automatically insert if empty
DEFAULT_BOOKS = [
    {
        "title": "Operating Systems: Internals and Design Principles",
        "author": "William Stallings",
        "category": "Technical",
        "review": "Best Operating System reference book.",
        "status": "Available",
        "image_url": "/static/images/book1.jpg"
    },
    {
        "title": "This is Marketing",
        "author": "Seth Godin",
        "category": "Marketing",
        "review": "Explains modern marketing.",
        "status": "Available",
        "image_url": "/static/images/book2.jpg"
    },
    {
        "title": "The Psychology Of Money",
        "author": "Morgan Housel",
        "category": "Finance",
        "review": "Excellent finance book.",
        "status": "Available",
        "image_url": "/static/images/book3.jpg"
    },
    {
        "title": "Atomic Habits",
        "author": "James Clear",
        "category": "Motivation",
        "review": "Improves habits.",
        "status": "Available",
        "image_url": "/static/images/book4.jpg"
    },
    {
        "title": "The Power of Positive Thinking",
        "author": "Norman Vincent Peale",
        "category": "Motivation",
        "review": "Builds confidence.",
        "status": "Available",
        "image_url": "/static/images/book5.jpg"
    }
]

def seed_database():
    """Seed default collections if they do not exist."""
    if not mongo_connected or db is None:
        return
    
    # 1. Seed Books
    if db.books.count_documents({}) == 0:
        db.books.insert_many(DEFAULT_BOOKS)
        print("[INFO] Seeded default books into MongoDB.")
        
    # 2. Seed Default Admin if none exists
    if db.admins.count_documents({}) == 0:
        db.admins.insert_one({
            "username": "admin",
            "password": "admin123",  # Plain text for simple starter project; use hashing in production
            "name": "Head Librarian"
        })
        print("[INFO] Seeded default librarian (admin/admin123) into MongoDB.")

# Execute seeding
seed_database()

# ==========================================
# MOCK DB FALLBACK (For offline/sandbox use)
# ==========================================
class LocalMockDB:
    """A thread-safe, simple JSON-like mock DB to ensure the Python app runs without MongoDB."""
    def __init__(self):
        self.books = [dict(b, _id=str(i+1)) for i, b in enumerate(DEFAULT_BOOKS)]
        self.admins = [{"_id": "1", "username": "admin", "password": "admin123", "name": "Head Librarian"}]
        self.students = []
        self.requests = []
        self.transactions = []
        self.logins = []

mock_db = LocalMockDB()

def get_db_collection(col_name):
    """Utility to get collection, returns Mongo Collection or Mock List wrapper."""
    if mongo_connected and db is not None:
        return db[col_name]
    return getattr(mock_db, col_name)

# Helper functions for cross-platform DB operations (Works for pymongo or mock fallback)
def db_find(collection_name, query=None):
    col = get_db_collection(collection_name)
    if mongo_connected and db is not None:
        query = query or {}
        # Simple translation for MongoDB ObjectIDs if needed
        if query and "_id" in query and isinstance(query["_id"], str):
            try:
                query["_id"] = ObjectId(query["_id"])
            except:
                pass
        return list(col.find(query))
    else:
        # Mock search
        query = query or {}
        results = []
        for item in col:
            match = True
            for k, v in query.items():
                if k == "_id":
                    if str(item.get("_id")) != str(v):
                        match = False
                elif item.get(k) != v:
                    match = False
            if match:
                results.append(item)
        return results

def db_find_one(collection_name, query):
    results = db_find(collection_name, query)
    return results[0] if results else None

def db_insert_one(collection_name, data):
    col = get_db_collection(collection_name)
    if mongo_connected and db is not None:
        # If ID is specified as string, convert
        if "_id" in data and isinstance(data["_id"], str) and len(data["_id"]) == 24:
            data["_id"] = ObjectId(data["_id"])
        result = col.insert_one(data)
        return str(result.inserted_id)
    else:
        data = dict(data)
        if "_id" not in data:
            data["_id"] = str(len(col) + 1)
        col.append(data)
        return str(data["_id"])

def db_update_one(collection_name, query, update_data):
    col = get_db_collection(collection_name)
    if mongo_connected and db is not None:
        if query and "_id" in query and isinstance(query["_id"], str):
            try:
                query["_id"] = ObjectId(query["_id"])
            except:
                pass
        col.update_one(query, {"$set": update_data})
    else:
        item = db_find_one(collection_name, query)
        if item:
            item.update(update_data)

def db_delete_one(collection_name, query):
    col = get_db_collection(collection_name)
    if mongo_connected and db is not None:
        if query and "_id" in query and isinstance(query["_id"], str):
            try:
                query["_id"] = ObjectId(query["_id"])
            except:
                pass
        col.delete_one(query)
    else:
        item = db_find_one(collection_name, query)
        if item in col:
            col.remove(item)

# ==========================================
# FLASK ROUTING (MVC Controller)
# ==========================================

@app.context_processor
def inject_now():
    """Inject current datetime context to templates."""
    return {'now': datetime.utcnow()}

@app.route('/')
def index():
    """Home / Landing Page."""
    # Count stats for landing page if needed
    books = db_find('books')
    total_books = len(books)
    available_books = len([b for b in books if b.get('status') == 'Available'])
    
    return render_template('index.html', 
                           total_books=total_books, 
                           available_books=available_books,
                           mongo_status=mongo_connected)

# ----------------- Student Routes -----------------

@app.route('/student/login', methods=['GET', 'POST'])
def student_login():
    """Student Login Router."""
    if 'student_id' in session:
        return redirect(url_for('student_dashboard'))
        
    if request.method == 'POST':
        student_id = request.form.get('student_id', '').strip()
        student_name = request.form.get('student_name', '').strip()
        department = request.form.get('department', '').strip()
        
        # Validation
        if not student_id or not student_name or not department:
            flash("All fields are required!", "danger")
            return redirect(url_for('student_login'))
            
        # Store in MongoDB (or Mock DB)
        student_data = {
            "student_id": student_id,
            "student_name": student_name,
            "department": department,
            "login_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        # Check if student already exists, otherwise add
        existing_student = db_find_one('students', {"student_id": student_id})
        if not existing_student:
            db_insert_one('students', {
                "student_id": student_id,
                "student_name": student_name,
                "department": department,
                "joined_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })
            
        # Store login history log
        db_insert_one('logins', {
            "user_id": student_id,
            "user_name": student_name,
            "role": "Student",
            "department": department,
            "login_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })
        
        # Save info in session
        session['student_id'] = student_id
        session['student_name'] = student_name
        session['department'] = department
        session['role'] = 'student'
        
        flash(f"Welcome back, {student_name}!", "success")
        return redirect(url_for('student_dashboard'))
        
    return render_template('student_login.html')

@app.route('/student/dashboard')
def student_dashboard():
    """Student Dashboard router."""
    if 'student_id' not in session or session.get('role') != 'student':
        flash("Please login as a student to access the dashboard.", "warning")
        return redirect(url_for('student_login'))
        
    student_id = session['student_id']
    
    # Fetch all books
    all_books = db_find('books')
    
    # Fetch student's current requests & transactions
    my_requests = db_find('requests', {"student_id": student_id})
    my_transactions = db_find('transactions', {"student_id": student_id})
    
    # Group books by categories
    categories = sorted(list(set([b.get('category', 'General') for b in all_books])))
    
    return render_template('student_dashboard.html',
                           books=all_books,
                           categories=categories,
                           my_requests=my_requests,
                           my_transactions=my_transactions)

@app.route('/student/logout')
def student_logout():
    """Logout current student."""
    session.clear()
    flash("Logged out successfully.", "info")
    return redirect(url_for('index'))

@app.route('/book/<book_id>')
def book_details(book_id):
    """View Book Details and Reviews."""
    book = db_find_one('books', {"_id": book_id})
    if not book:
        flash("Book not found!", "danger")
        return redirect(url_for('student_dashboard'))
        
    return render_template('book_details.html', book=book)

@app.route('/search', methods=['GET', 'POST'])
def search_books():
    """Search books route."""
    query = request.args.get('q', '').strip()
    category_filter = request.args.get('category', '').strip()
    
    books = db_find('books')
    results = []
    
    for book in books:
        # Text matching
        match_text = True
        if query:
            q_lower = query.lower()
            title_match = q_lower in book.get('title', '').lower()
            author_match = q_lower in book.get('author', '').lower()
            cat_match = q_lower in book.get('category', '').lower()
            match_text = title_match or author_match or cat_match
            
        # Category matching
        match_cat = True
        if category_filter:
            match_cat = book.get('category', '').lower() == category_filter.lower()
            
        if match_text and match_cat:
            results.append(book)
            
    return render_template('search_result.html', results=results, query=query, category=category_filter)

@app.route('/request-book/<book_id>', methods=['POST'])
def request_book(book_id):
    """Request a book."""
    if 'student_id' not in session or session.get('role') != 'student':
        flash("Please login to request books.", "warning")
        return redirect(url_for('student_login'))
        
    student_id = session['student_id']
    student_name = session['student_name']
    department = session['department']
    
    # Check if book exists and is available
    book = db_find_one('books', {"_id": book_id})
    if not book:
        flash("Book not found!", "danger")
        return redirect(url_for('student_dashboard'))
        
    if book.get('status') != 'Available':
        flash("Book is already issued or requested!", "warning")
        return redirect(url_for('student_dashboard'))
        
    # Check if user has already requested this book
    existing_req = db_find_one('requests', {"student_id": student_id, "book_id": book_id, "status": "Pending"})
    if existing_req:
        flash("You already have a pending request for this book!", "warning")
        return redirect(url_for('student_dashboard'))
        
    # Create request
    request_doc = {
        "student_id": student_id,
        "student_name": student_name,
        "department": department,
        "book_id": book_id,
        "book_title": book.get('title'),
        "book_author": book.get('author'),
        "request_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "status": "Pending"
    }
    db_insert_one('requests', request_doc)
    
    # Update book status to 'Requested'
    db_update_one('books', {"_id": book_id}, {"status": "Requested"})
    
    flash(f"Request for '{book.get('title')}' submitted successfully!", "success")
    return redirect(url_for('student_dashboard'))

# ----------------- Librarian (Admin) Routes -----------------

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    """Librarian Login."""
    if 'admin_user' in session:
        return redirect(url_for('admin_dashboard'))
        
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        
        if not username or not password:
            flash("All fields are required!", "danger")
            return redirect(url_for('admin_login'))
            
        # Standard lookup
        admin = db_find_one('admins', {"username": username, "password": password})
        if admin or (username == 'admin' and password == 'admin123'):
            # Success
            session['admin_user'] = username
            session['admin_name'] = admin.get('name', 'Head Librarian') if admin else 'Head Librarian'
            session['role'] = 'admin'
            
            # Store Login history log
            db_insert_one('logins', {
                "user_id": username,
                "user_name": session['admin_name'],
                "role": "Librarian",
                "department": "Library Department",
                "login_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })
            
            flash("Librarian Login Successful!", "success")
            return redirect(url_for('admin_dashboard'))
        else:
            flash("Invalid Username or Password!", "danger")
            return redirect(url_for('admin_login'))
            
    return render_template('admin_login.html')

@app.route('/admin/dashboard')
def admin_dashboard():
    """Admin/Librarian Dashboard."""
    if 'admin_user' not in session or session.get('role') != 'admin':
        flash("Access Denied! Please login as Librarian first.", "danger")
        return redirect(url_for('admin_login'))
        
    # Get statistics
    books = db_find('books')
    students = db_find('students')
    requests = db_find('requests')
    transactions = db_find('transactions')
    logins = db_find('logins')
    
    total_students = len(students)
    total_books = len(books)
    books_available = len([b for b in books if b.get('status') == 'Available'])
    books_issued = len([b for b in books if b.get('status') == 'Issued'])
    pending_requests = len([r for r in requests if r.get('status') == 'Pending'])
    
    # Filter logins from today
    today_str = datetime.now().strftime("%Y-%m-%d")
    todays_logins = [l for l in logins if l.get('login_time', '').startswith(today_str)]
    
    return render_template('admin_dashboard.html',
                           books=books,
                           students=students,
                           requests=requests,
                           transactions=transactions,
                           todays_logins=todays_logins,
                           total_students=total_students,
                           total_books=total_books,
                           books_available=books_available,
                           books_issued=books_issued,
                           pending_requests=pending_requests)

@app.route('/admin/add-book', methods=['POST'])
def add_book():
    """Add a new book (Librarian CRUD)."""
    if 'admin_user' not in session or session.get('role') != 'admin':
        flash("Unauthorized!", "danger")
        return redirect(url_for('admin_login'))
        
    title = request.form.get('title', '').strip()
    author = request.form.get('author', '').strip()
    category = request.form.get('category', '').strip()
    review = request.form.get('review', '').strip()
    
    if not title or not author or not category:
        flash("Title, Author, and Category are required!", "danger")
        return redirect(url_for('admin_dashboard'))
        
    new_book = {
        "title": title,
        "author": author,
        "category": category,
        "review": review,
        "status": "Available",
        "image_url": "/static/images/book1.jpg"  # Default fallback image
    }
    
    db_insert_one('books', new_book)
    flash("Book added successfully!", "success")
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/edit-book/<book_id>', methods=['POST'])
def edit_book(book_id):
    """Update a book details."""
    if 'admin_user' not in session or session.get('role') != 'admin':
        flash("Unauthorized!", "danger")
        return redirect(url_for('admin_login'))
        
    title = request.form.get('title', '').strip()
    author = request.form.get('author', '').strip()
    category = request.form.get('category', '').strip()
    review = request.form.get('review', '').strip()
    
    if not title or not author or not category:
        flash("All main fields are required!", "danger")
        return redirect(url_for('admin_dashboard'))
        
    db_update_one('books', {"_id": book_id}, {
        "title": title,
        "author": author,
        "category": category,
        "review": review
    })
    
    flash("Book updated successfully!", "success")
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/delete-book/<book_id>')
def delete_book(book_id):
    """Delete a book from library."""
    if 'admin_user' not in session or session.get('role') != 'admin':
        flash("Unauthorized!", "danger")
        return redirect(url_for('admin_login'))
        
    # Check book status
    book = db_find_one('books', {"_id": book_id})
    if book and book.get('status') == 'Issued':
        flash("Cannot delete an issued book!", "danger")
        return redirect(url_for('admin_dashboard'))
        
    db_delete_one('books', {"_id": book_id})
    flash("Book deleted from library successfully.", "success")
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/approve-request/<request_id>')
def approve_request(request_id):
    """Approve book request & Issue Book."""
    if 'admin_user' not in session or session.get('role') != 'admin':
        flash("Unauthorized!", "danger")
        return redirect(url_for('admin_login'))
        
    req = db_find_one('requests', {"_id": request_id})
    if not req:
        flash("Request not found!", "danger")
        return redirect(url_for('admin_dashboard'))
        
    book_id = req.get('book_id')
    book = db_find_one('books', {"_id": book_id})
    
    # Approve request
    db_update_one('requests', {"_id": request_id}, {"status": "Approved"})
    
    # Update book status to 'Issued'
    db_update_one('books', {"_id": book_id}, {"status": "Issued"})
    
    # Log Transaction
    transaction_doc = {
        "student_id": req.get('student_id'),
        "student_name": req.get('student_name'),
        "department": req.get('department'),
        "book_id": book_id,
        "book_title": req.get('book_title'),
        "issue_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "return_date": "N/A",
        "status": "Issued"
    }
    db_insert_one('transactions', transaction_doc)
    
    flash(f"Book request approved. '{req.get('book_title')}' has been issued to {req.get('student_name')}.", "success")
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/reject-request/<request_id>')
def reject_request(request_id):
    """Reject a pending book request."""
    if 'admin_user' not in session or session.get('role') != 'admin':
        flash("Unauthorized!", "danger")
        return redirect(url_for('admin_login'))
        
    req = db_find_one('requests', {"_id": request_id})
    if not req:
        flash("Request not found!", "danger")
        return redirect(url_for('admin_dashboard'))
        
    book_id = req.get('book_id')
    
    # Update Request status to Rejected
    db_update_one('requests', {"_id": request_id}, {"status": "Rejected"})
    
    # Make book available again
    db_update_one('books', {"_id": book_id}, {"status": "Available"})
    
    flash("Request has been rejected.", "info")
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/return-book/<transaction_id>')
def return_book(transaction_id):
    """Mark issued book as returned (Librarian)."""
    if 'admin_user' not in session or session.get('role') != 'admin':
        flash("Unauthorized!", "danger")
        return redirect(url_for('admin_login'))
        
    transaction = db_find_one('transactions', {"_id": transaction_id})
    if not transaction:
        flash("Transaction record not found!", "danger")
        return redirect(url_for('admin_dashboard'))
        
    book_id = transaction.get('book_id')
    
    # Update transaction
    db_update_one('transactions', {"_id": transaction_id}, {
        "status": "Returned",
        "return_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    })
    
    # Reset book status to Available
    db_update_one('books', {"_id": book_id}, {"status": "Available"})
    
    flash(f"Book returned successfully. Transaction completed.", "success")
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/logout')
def admin_logout():
    """Librarian Logout."""
    session.clear()
    flash("Librarian logged out successfully.", "info")
    return redirect(url_for('index'))

@app.route('/transaction-history')
def transaction_history():
    """View full transactions."""
    if 'role' not in session:
        flash("Please login to view history.", "warning")
        return redirect(url_for('index'))
        
    transactions = db_find('transactions')
    return render_template('transaction_history.html', transactions=transactions)

if __name__ == '__main__':
    # Bind to 0.0.0.0:3000 as required in sandboxed environment, but standard is fine
    app.run(host='0.0.0.0', port=3000, debug=True)
