import express from "express";
import path from "path";
import nunjucks from "nunjucks";
import session from "express-session";

// Declare module extension to keep TypeScript linter happy with custom session variables
declare module "express-session" {
  interface SessionData {
    student_id?: string;
    student_name?: string;
    department?: string;
    admin_user?: string;
    admin_name?: string;
    role?: string;
    flash?: Array<[string, string]>;
  }
}

const app = express();
const PORT = 3000;

// Setup session middleware
app.use(session({
  secret: "bibliotech_sandbox_session_secret_123",
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } // Set to false for preview iframe compatibility
}));

// Configure Nunjucks Template Engine (Jinja2 compatible)
nunjucks.configure("templates", {
  autoescape: true,
  express: app,
  watch: false
});

// Configure Express to parse form bodies
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static assets
app.use("/static", express.static(path.join(process.cwd(), "static")));

// In-Memory Stateful Store to make the Sandbox Demo fully interactive
const state = {
  books: [
    {
      _id: "book1",
      title: "Operating Systems: Internals and Design Principles",
      author: "William Stallings",
      category: "Technical",
      review: "Best Operating System reference book.",
      status: "Available",
      image_url: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=600&q=80"
    },
    {
      _id: "book2",
      title: "This is Marketing",
      author: "Seth Godin",
      category: "Marketing",
      review: "Explains modern marketing.",
      status: "Available",
      image_url: "https://images.unsplash.com/photo-1557804506-669a67965ba0?auto=format&fit=crop&w=600&q=80"
    },
    {
      _id: "book3",
      title: "The Psychology Of Money",
      author: "Morgan Housel",
      category: "Finance",
      review: "Excellent finance book.",
      status: "Available",
      image_url: "https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=600&q=80"
    },
    {
      _id: "book4",
      title: "Atomic Habits",
      author: "James Clear",
      category: "Motivation",
      review: "Improves habits.",
      status: "Available",
      image_url: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80"
    },
    {
      _id: "book5",
      title: "The Power of Positive Thinking",
      author: "Norman Vincent Peale",
      category: "Motivation",
      review: "Builds confidence.",
      status: "Available",
      image_url: "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=600&q=80"
    },
    {
      _id: "book6",
      title: "Clean Code: A Handbook of Agile Software Craftsmanship",
      author: "Robert C. Martin",
      category: "Software Engineering",
      review: "Must-read guide on writing clean, maintainable code.",
      status: "Available",
      image_url: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=600&q=80"
    },
    {
      _id: "book7",
      title: "Design Patterns: Elements of Reusable Object-Oriented Software",
      author: "Erich Gamma, Richard Helm, Ralph Johnson, John Vlissides",
      category: "Technical",
      review: "The classic Gang of Four reference on software design patterns.",
      status: "Available",
      image_url: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=600&q=80"
    },
    {
      _id: "book8",
      title: "Deep Work: Rules for Focused Success in a Distracted World",
      author: "Cal Newport",
      category: "Motivation",
      review: "Actionable strategies to eliminate distractions and boost output.",
      status: "Available",
      image_url: "https://images.unsplash.com/photo-1499750310107-5fef28a66643?auto=format&fit=crop&w=600&q=80"
    },
    {
      _id: "book9",
      title: "Introduction to Algorithms",
      author: "Thomas H. Cormen, Charles E. Leiserson, Ronald L. Rivest, Clifford Stein",
      category: "Technical",
      review: "Comprehensive textbook on algorithms and data structures.",
      status: "Available",
      image_url: "https://images.unsplash.com/photo-1509228468518-180dd4864904?auto=format&fit=crop&w=600&q=80"
    },
    {
      _id: "book10",
      title: "Zero to One: Notes on Startups, or How to Build the Future",
      author: "Peter Thiel, Blake Masters",
      category: "Marketing",
      review: "Insightful perspective on innovation and entrepreneurship.",
      status: "Available",
      image_url: "https://images.unsplash.com/photo-1553729459-efe14ef6055d?auto=format&fit=crop&w=600&q=80"
    },
    {
      _id: "book11",
      title: "Artificial Intelligence: A Modern Approach",
      author: "Stuart Russell, Peter Norvig",
      category: "Technical",
      review: "The authoritative guide to core artificial intelligence concepts.",
      status: "Available",
      image_url: "https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&w=600&q=80"
    },
    {
      _id: "book12",
      title: "Thinking, Fast and Slow",
      author: "Daniel Kahneman",
      category: "Psychology",
      review: "Explores the two systems that drive human decision making.",
      status: "Available",
      image_url: "https://images.unsplash.com/photo-1457369804613-52c61a468e7d?auto=format&fit=crop&w=600&q=80"
    },
    {
      _id: "book13",
      title: "The Pragmatic Programmer",
      author: "Andrew Hunt, David Thomas",
      category: "Software Engineering",
      review: "Timeless advice for career growth and code craftsmanship.",
      status: "Available",
      image_url: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=600&q=80"
    },
    {
      _id: "book14",
      title: "Rich Dad Poor Dad",
      author: "Robert T. Kiyosaki",
      category: "Finance",
      review: "Fundamental principles of financial literacy and wealth creation.",
      status: "Available",
      image_url: "https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?auto=format&fit=crop&w=600&q=80"
    },
    {
      _id: "book15",
      title: "Computer Networks: A Systems Approach",
      author: "Larry L. Peterson, Bruce S. Davie",
      category: "Technical",
      review: "In-depth breakdown of network protocols and architecture.",
      status: "Available",
      image_url: "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=600&q=80"
    }
  ],
  students: [
    { student_id: "CS2026101", student_name: "Alice Smith", department: "Computer Science & Engineering", joined_at: "2026-07-20 08:00:00" },
    { student_id: "IT2026102", student_name: "Bob Johnson", department: "Information Technology", joined_at: "2026-07-20 08:15:00" }
  ],
  requests: [
    { _id: "req1", student_id: "CS2026101", student_name: "Alice Smith", department: "Computer Science & Engineering", book_id: "book2", book_title: "This is Marketing", book_author: "Seth Godin", request_date: "2026-07-20 08:30:00", status: "Pending" }
  ],
  transactions: [
    { _id: "trans1", student_id: "IT2026102", student_name: "Bob Johnson", department: "Information Technology", book_id: "book3", book_title: "The Psychology Of Money", issue_date: "2026-07-18 10:00:00", return_date: "N/A", status: "Issued" }
  ],
  logins: [
    { user_id: "IT2026102", user_name: "Bob Johnson", role: "Student", department: "Information Technology", login_time: "2026-07-20 08:15:00" }
  ]
};

// Seed database status
state.books[2].status = "Issued"; // Align with seeded transaction above

// Flash helper function
function flash(req: express.Request, category: string, message: string) {
  if (!req.session.flash) {
    req.session.flash = [];
  }
  req.session.flash.push([category, message]);
}

// Global Middlewares to inject session & flash details to Nunjucks engine
app.use((req, res, next) => {
  res.locals.session = req.session;
  res.locals.get_flashed_messages = (options?: { with_categories?: boolean }) => {
    const messages = req.session.flash || [];
    req.session.flash = []; // Clear flash on read
    return messages;
  };
  next();
});

// ==========================================
// ROUTES - Direct replica of Python Flask API
// ==========================================

// 1. Landing / Home Page
app.get("/", (req, res) => {
  const total_books = state.books.length;
  const available_books = state.books.filter(b => b.status === "Available").length;
  res.render("index.html", {
    total_books,
    available_books,
    mongo_status: false // Express preview mode uses Sandboxed local state
  });
});

// 2. Student Authentication
app.get("/student/login", (req, res) => {
  if (req.session.student_id) {
    return res.redirect("/student/dashboard");
  }
  res.render("student_login.html");
});

app.post("/student/login", (req, res) => {
  const { student_id, student_name, department } = req.body;

  if (!student_id || !student_name || !department) {
    flash(req, "danger", "All fields are required!");
    return res.redirect("/student/login");
  }

  // Check if student is in our records
  const existing = state.students.find(s => s.student_id === student_id);
  if (!existing) {
    state.students.push({
      student_id,
      student_name,
      department,
      joined_at: new Date().toISOString().slice(0, 19).replace('T', ' ')
    });
  }

  // Log in
  req.session.student_id = student_id;
  req.session.student_name = student_name;
  req.session.department = department;
  req.session.role = "student";

  // Create audit log
  state.logins.push({
    user_id: student_id,
    user_name: student_name,
    role: "Student",
    department,
    login_time: new Date().toISOString().slice(0, 19).replace('T', ' ')
  });

  flash(req, "success", `Welcome back, ${student_name}!`);
  res.redirect("/student/dashboard");
});

app.get("/student/dashboard", (req, res) => {
  if (!req.session.student_id || req.session.role !== "student") {
    flash(req, "warning", "Please login as a student to access the dashboard.");
    return res.redirect("/student/login");
  }

  const s_id = req.session.student_id;
  const my_requests = state.requests.filter(r => r.student_id === s_id);
  const my_transactions = state.transactions.filter(t => t.student_id === s_id);
  const categories = Array.from(new Set(state.books.map(b => b.category))).sort();

  res.render("student_dashboard.html", {
    books: state.books,
    categories,
    my_requests,
    my_transactions
  });
});

app.get("/student/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/");
  });
});

// 3. Book details view
app.get("/book/:book_id", (req, res) => {
  const book = state.books.find(b => b._id === req.params.book_id);
  if (!book) {
    flash(req, "danger", "Book not found!");
    return res.redirect("/");
  }
  res.render("book_details.html", { book });
});

// 4. Searching books
app.get("/search", (req, res) => {
  const query = (req.query.q as string || "").toLowerCase().trim();
  const categoryFilter = (req.query.category as string || "").toLowerCase().trim();

  const results = state.books.filter(book => {
    let matchText = true;
    if (query) {
      matchText = book.title.toLowerCase().includes(query) ||
                  book.author.toLowerCase().includes(query) ||
                  book.category.toLowerCase().includes(query);
    }

    let matchCategory = true;
    if (categoryFilter) {
      matchCategory = book.category.toLowerCase() === categoryFilter;
    }

    return matchText && matchCategory;
  });

  res.render("search_result.html", {
    results,
    query: req.query.q || "",
    category: req.query.category || ""
  });
});

// 5. Submit book requests
app.post("/request-book/:book_id", (req, res) => {
  if (!req.session.student_id || req.session.role !== "student") {
    flash(req, "warning", "Please login as student first.");
    return res.redirect("/student/login");
  }

  const bookId = req.params.book_id;
  const book = state.books.find(b => b._id === bookId);

  if (!book) {
    flash(req, "danger", "Book not found.");
    return res.redirect("/student/dashboard");
  }

  if (book.status !== "Available") {
    flash(req, "warning", "Book is already requested or issued.");
    return res.redirect("/student/dashboard");
  }

  // Create request
  const newReq = {
    _id: "req_" + Date.now(),
    student_id: req.session.student_id,
    student_name: req.session.student_name || "Unknown",
    department: req.session.department || "General",
    book_id: bookId,
    book_title: book.title,
    book_author: book.author,
    request_date: new Date().toISOString().slice(0, 19).replace('T', ' '),
    status: "Pending"
  };

  state.requests.push(newReq);
  book.status = "Requested";

  flash(req, "success", `Request submitted successfully for '${book.title}'`);
  res.redirect("/student/dashboard");
});

// 6. Librarian Authentication
app.get("/admin/login", (req, res) => {
  if (req.session.admin_user) {
    return res.redirect("/admin/dashboard");
  }
  res.render("admin_login.html");
});

app.post("/admin/login", (req, res) => {
  const { username, password } = req.body;

  if (username === "admin" && password === "admin123") {
    req.session.admin_user = "admin";
    req.session.admin_name = "Head Librarian";
    req.session.role = "admin";

    // Log admin entry
    state.logins.push({
      user_id: "admin",
      user_name: "Head Librarian",
      role: "Librarian",
      department: "Library Department",
      login_time: new Date().toISOString().slice(0, 19).replace('T', ' ')
    });

    flash(req, "success", "Librarian console unlocked.");
    res.redirect("/admin/dashboard");
  } else {
    flash(req, "danger", "Invalid administrative credentials!");
    res.redirect("/admin/login");
  }
});

// 7. Librarian Dashboard & Actions
app.get("/admin/dashboard", (req, res) => {
  if (!req.session.admin_user || req.session.role !== "admin") {
    flash(req, "danger", "Administrative lock. Please login.");
    return res.redirect("/admin/login");
  }

  const total_students = state.students.length;
  const total_books = state.books.length;
  const books_available = state.books.filter(b => b.status === "Available").length;
  const books_issued = state.books.filter(b => b.status === "Issued").length;
  const pending_requests = state.requests.filter(r => r.status === "Pending").length;

  const today_str = new Date().toISOString().slice(0, 10);
  const todays_logins = state.logins.filter(l => l.login_time.startsWith(today_str));

  res.render("admin_dashboard.html", {
    books: state.books,
    students: state.students,
    requests: state.requests,
    transactions: state.transactions,
    todays_logins,
    total_students,
    total_books,
    books_available,
    books_issued,
    pending_requests
  });
});

app.post("/admin/add-book", (req, res) => {
  if (!req.session.admin_user || req.session.role !== "admin") {
    return res.status(403).send("Unauthorized");
  }

  const { title, author, category, review } = req.body;
  if (!title || !author || !category) {
    flash(req, "danger", "All fields are required to register a book.");
    return res.redirect("/admin/dashboard");
  }

  const newBook = {
    _id: "book_" + Date.now(),
    title,
    author,
    category,
    review: review || "",
    status: "Available",
    image_url: "/static/images/book1.jpg"
  };

  state.books.push(newBook);
  flash(req, "success", `Book '${title}' successfully added to catalog.`);
  res.redirect("/admin/dashboard");
});

app.get("/admin/delete-book/:book_id", (req, res) => {
  if (!req.session.admin_user || req.session.role !== "admin") {
    return res.status(403).send("Unauthorized");
  }

  const bookId = req.params.book_id;
  const bookIndex = state.books.findIndex(b => b._id === bookId);

  if (bookIndex !== -1) {
    const book = state.books[bookIndex];
    if (book.status === "Issued") {
      flash(req, "danger", "Cannot delete a book that is currently issued!");
    } else {
      state.books.splice(bookIndex, 1);
      flash(req, "success", `Deleted book from catalog.`);
    }
  }

  res.redirect("/admin/dashboard");
});

app.get("/admin/approve-request/:request_id", (req, res) => {
  if (!req.session.admin_user || req.session.role !== "admin") {
    return res.status(403).send("Unauthorized");
  }

  const reqId = req.params.request_id;
  const requestDoc = state.requests.find(r => r._id === reqId);

  if (requestDoc && requestDoc.status === "Pending") {
    const book = state.books.find(b => b._id === requestDoc.book_id);
    if (book) {
      requestDoc.status = "Approved";
      book.status = "Issued";

      // Log transaction
      const transId = "trans_" + Date.now();
      state.transactions.push({
        _id: transId,
        student_id: requestDoc.student_id,
        student_name: requestDoc.student_name,
        department: requestDoc.department,
        book_id: book._id,
        book_title: book.title,
        issue_date: new Date().toISOString().slice(0, 19).replace('T', ' '),
        return_date: "N/A",
        status: "Issued"
      });

      flash(req, "success", `Approved request. Issued '${book.title}' to ${requestDoc.student_name}`);
    }
  }

  res.redirect("/admin/dashboard");
});

app.get("/admin/reject-request/:request_id", (req, res) => {
  if (!req.session.admin_user || req.session.role !== "admin") {
    return res.status(403).send("Unauthorized");
  }

  const reqId = req.params.request_id;
  const requestDoc = state.requests.find(r => r._id === reqId);

  if (requestDoc && requestDoc.status === "Pending") {
    requestDoc.status = "Rejected";
    const book = state.books.find(b => b._id === requestDoc.book_id);
    if (book) {
      book.status = "Available";
    }
    flash(req, "info", "Student request rejected.");
  }

  res.redirect("/admin/dashboard");
});

app.get("/admin/return-book/:transaction_id", (req, res) => {
  if (!req.session.admin_user || req.session.role !== "admin") {
    return res.status(403).send("Unauthorized");
  }

  const transId = req.params.transaction_id;
  const trans = state.transactions.find(t => t._id === transId);

  if (trans && trans.status === "Issued") {
    trans.status = "Returned";
    trans.return_date = new Date().toISOString().slice(0, 19).replace('T', ' ');

    const book = state.books.find(b => b._id === trans.book_id);
    if (book) {
      book.status = "Available";
    }

    flash(req, "success", `Book '${trans.book_title}' successfully returned to library vault.`);
  }

  res.redirect("/admin/dashboard");
});

app.get("/admin/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/");
  });
});

// 8. General transaction audit logger
app.get("/transaction-history", (req, res) => {
  if (!req.session.role) {
    flash(req, "warning", "Please authenticate to view system ledger logs.");
    return res.redirect("/");
  }
  res.render("transaction_history.html", { transactions: state.transactions });
});

// Start Express Listener on port 3000
app.listen(PORT, "0.0.0.0", () => {
  console.log(`[INFO] Interactive preview dev server running at http://localhost:${PORT}`);
});
