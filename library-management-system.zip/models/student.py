from datetime import datetime
from database.db import Database

class StudentModel:
    """
    Student Data Model & Query Operations.
    Manages student logins, registration records, and session history in MongoDB.
    """
    
    @staticmethod
    def register_or_login(student_id, student_name, department):
        """
        Record student login event and register new student profile if not exists.
        """
        db = Database.get_db()
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        student_data = {
            "student_id": student_id,
            "student_name": student_name,
            "department": department,
            "last_login": timestamp
        }

        if db is not None:
            # Update student info or insert if new
            db.students.update_one(
                {"student_id": student_id},
                {"$set": student_data},
                upsert=True
            )
            # Record in login history log
            db.logins.insert_one({
                "role": "student",
                "student_id": student_id,
                "student_name": student_name,
                "department": department,
                "login_time": timestamp
            })

        return student_data

    @staticmethod
    def get_all_students():
        """Retrieve total list of registered students."""
        db = Database.get_db()
        if db is not None:
            return list(db.students.find({}, {"_id": 0}))
        return []

    @staticmethod
    def get_total_count():
        """Get total count of unique registered students."""
        db = Database.get_db()
        if db is not None:
            return db.students.count_documents({})
        return 0
