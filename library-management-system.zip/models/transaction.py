from datetime import datetime
from database.db import Database
from models.book import BookModel

class TransactionModel:
    """
    Transaction & Book Request Ledger Data Model.
    Manages student issue requests, librarian approvals, book returns, and log history.
    """

    @staticmethod
    def create_request(student_id, student_name, department, book_id, book_title):
        """
        Record a student request for a book and update book status to 'Requested'.
        """
        db = Database.get_db()
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        req_data = {
            "request_id": f"REQ-{int(datetime.now().timestamp())}",
            "student_id": student_id,
            "student_name": student_name,
            "department": department,
            "book_id": book_id,
            "book_title": book_title,
            "request_date": timestamp,
            "status": "Pending"
        }

        if db is not None:
            db.requests.insert_one(req_data)
        
        # Update book status to 'Requested'
        BookModel.update_status(book_id, "Requested")
        return req_data

    @staticmethod
    def get_pending_requests():
        """Fetch all requests awaiting librarian approval."""
        db = Database.get_db()
        if db is not None:
            return list(db.requests.find({"status": "Pending"}, {"_id": 0}))
        return []

    @staticmethod
    def approve_request(request_id):
        """
        Approve pending student request, update request status, change book to 'Issued',
        and log entry in transactions ledger.
        """
        db = Database.get_db()
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        if db is not None:
            req = db.requests.find_one({"request_id": request_id})
            if req:
                # Update request status to Approved
                db.requests.update_one({"request_id": request_id}, {"$set": {"status": "Approved"}})
                
                # Update book status to Issued
                BookModel.update_status(req["book_id"], "Issued")

                # Insert into transaction history ledger
                tx_data = {
                    "transaction_id": f"TX-{int(datetime.now().timestamp())}",
                    "student_id": req["student_id"],
                    "student_name": req["student_name"],
                    "department": req.get("department", "CSE"),
                    "book_id": req["book_id"],
                    "book_title": req["book_title"],
                    "issue_date": timestamp,
                    "return_date": "N/A",
                    "status": "Issued"
                }
                db.transactions.insert_one(tx_data)
                return True
        return False

    @staticmethod
    def return_book(book_id):
        """
        Mark issued book as Returned, set book status to 'Available',
        and record return timestamp in transaction history ledger.
        """
        db = Database.get_db()
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        if db is not None:
            # Update transaction record
            db.transactions.update_one(
                {"book_id": book_id, "status": "Issued"},
                {"$set": {"status": "Returned", "return_date": timestamp}}
            )
            # Update book status back to Available
            BookModel.update_status(book_id, "Available")
            return True
        else:
            BookModel.update_status(book_id, "Available")
            return True

    @staticmethod
    def get_all_transactions():
        """Retrieve full audit log transaction history."""
        db = Database.get_db()
        if db is not None:
            return list(db.transactions.find({}, {"_id": 0}).sort("issue_date", -1))
        return []

    @staticmethod
    def get_pending_count():
        """Get count of pending requests."""
        db = Database.get_db()
        if db is not None:
            return db.requests.count_documents({"status": "Pending"})
        return 0
