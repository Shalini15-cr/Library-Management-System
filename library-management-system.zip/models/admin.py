from datetime import datetime
from database.db import Database

class AdminModel:
    """
    Librarian / Admin Authentication & Operations Model.
    """
    
    @staticmethod
    def verify_credentials(username, password):
        """
        Authenticate admin username and password.
        Default master admin credential fallback: admin / admin123
        """
        db = Database.get_db()
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Master admin default check
        if username == "admin" and password == "admin123":
            if db is not None:
                # Store login event in history log
                db.logins.insert_one({
                    "role": "admin",
                    "username": username,
                    "login_time": timestamp
                })
            return True, "Head Librarian"
        
        # Check custom admin records in MongoDB
        if db is not None:
            admin_record = db.admins.find_one({"username": username, "password": password})
            if admin_record:
                db.logins.insert_one({
                    "role": "admin",
                    "username": username,
                    "login_time": timestamp
                })
                return True, admin_record.get("name", username)

        return False, None

    @staticmethod
    def get_login_history():
        """Retrieve full login audit trail."""
        db = Database.get_db()
        if db is not None:
            return list(db.logins.find({}, {"_id": 0}).sort("login_time", -1))
        return []
