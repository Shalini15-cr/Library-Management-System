from database.db import Database

# Initial Default Book Collection required by project specifications
INITIAL_BOOKS = [
    {
        "id": "book1",
        "title": "Operating Systems: Internals and Design Principles",
        "author": "William Stallings",
        "category": "Technical",
        "status": "Available",
        "review": "Excellent reference book for Operating Systems.",
        "image_url": "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=600&q=80"
    },
    {
        "id": "book2",
        "title": "This is Marketing",
        "author": "Seth Godin",
        "category": "Marketing",
        "status": "Available",
        "review": "Modern marketing concepts explained simply.",
        "image_url": "https://images.unsplash.com/photo-1557804506-669a67965ba0?auto=format&fit=crop&w=600&q=80"
    },
    {
        "id": "book3",
        "title": "The Psychology Of Money",
        "author": "Morgan Housel",
        "category": "Finance",
        "status": "Available",
        "review": "Explains financial behaviour and money management.",
        "image_url": "https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=600&q=80"
    },
    {
        "id": "book4",
        "title": "Atomic Habits",
        "author": "James Clear",
        "category": "Motivation",
        "status": "Available",
        "review": "Builds positive habits and consistency.",
        "image_url": "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80"
    },
    {
        "id": "book5",
        "title": "The Power of Positive Thinking",
        "author": "Norman Vincent Peale",
        "category": "Motivation",
        "status": "Available",
        "review": "Improves confidence and positive thinking.",
        "image_url": "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=600&q=80"
    },
    {
        "id": "book6",
        "title": "Clean Code: A Handbook of Agile Software Craftsmanship",
        "author": "Robert C. Martin",
        "category": "Software Engineering",
        "status": "Available",
        "review": "Must-read guide on writing clean, maintainable, and refactored code.",
        "image_url": "https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=600&q=80"
    },
    {
        "id": "book7",
        "title": "Design Patterns: Elements of Reusable Object-Oriented Software",
        "author": "Erich Gamma, Richard Helm, Ralph Johnson, John Vlissides",
        "category": "Technical",
        "status": "Available",
        "review": "The classic Gang of Four reference on software architecture patterns.",
        "image_url": "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=600&q=80"
    },
    {
        "id": "book8",
        "title": "Deep Work: Rules for Focused Success in a Distracted World",
        "author": "Cal Newport",
        "category": "Motivation",
        "status": "Available",
        "review": "Provides actionable strategies to eliminate distractions and boost productivity.",
        "image_url": "https://images.unsplash.com/photo-1499750310107-5fef28a66643?auto=format&fit=crop&w=600&q=80"
    },
    {
        "id": "book9",
        "title": "Introduction to Algorithms",
        "author": "Thomas H. Cormen, Charles E. Leiserson, Ronald L. Rivest, Clifford Stein",
        "category": "Technical",
        "status": "Available",
        "review": "Comprehensive textbook on algorithms, data structures, and computational complexity.",
        "image_url": "https://images.unsplash.com/photo-1509228468518-180dd4864904?auto=format&fit=crop&w=600&q=80"
    },
    {
        "id": "book10",
        "title": "Zero to One: Notes on Startups, or How to Build the Future",
        "author": "Peter Thiel, Blake Masters",
        "category": "Marketing",
        "status": "Available",
        "review": "Insightful perspective on innovation, entrepreneurship, and creating new markets.",
        "image_url": "https://images.unsplash.com/photo-1553729459-efe14ef6055d?auto=format&fit=crop&w=600&q=80"
    },
    {
        "id": "book11",
        "title": "Artificial Intelligence: A Modern Approach",
        "author": "Stuart Russell, Peter Norvig",
        "category": "Technical",
        "status": "Available",
        "review": "The authoritative guide to core artificial intelligence concepts and machine learning.",
        "image_url": "https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&w=600&q=80"
    },
    {
        "id": "book12",
        "title": "Thinking, Fast and Slow",
        "author": "Daniel Kahneman",
        "category": "Psychology",
        "status": "Available",
        "review": "Explores the two systems that drive the way we think and make decisions.",
        "image_url": "https://images.unsplash.com/photo-1457369804613-52c61a468e7d?auto=format&fit=crop&w=600&q=80"
    },
    {
        "id": "book13",
        "title": "The Pragmatic Programmer",
        "author": "Andrew Hunt, David Thomas",
        "category": "Software Engineering",
        "status": "Available",
        "review": "Timeless advice for career growth, code craft, and software engineering discipline.",
        "image_url": "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=600&q=80"
    },
    {
        "id": "book14",
        "title": "Rich Dad Poor Dad",
        "author": "Robert T. Kiyosaki",
        "category": "Finance",
        "status": "Available",
        "review": "Fundamental principles of financial literacy, investments, and wealth management.",
        "image_url": "https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?auto=format&fit=crop&w=600&q=80"
    },
    {
        "id": "book15",
        "title": "Computer Networks: A Systems Approach",
        "author": "Larry L. Peterson, Bruce S. Davie",
        "category": "Technical",
        "status": "Available",
        "review": "In-depth breakdown of network architecture, protocols, and data communication.",
        "image_url": "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=600&q=80"
    }
]

class BookModel:
    """
    Book Catalog Data Model.
    Provides query, search, addition, status transition, and seed operations.
    """

    @staticmethod
    def seed_initial_books():
        """Ensure initial 5 books are present in MongoDB if empty."""
        db = Database.get_db()
        if db is not None:
            if db.books.count_documents({}) == 0:
                db.books.insert_many(INITIAL_BOOKS)
                print("[INFO] Seeded default 5 books into MongoDB collection 'books'.")

    @staticmethod
    def get_all_books():
        """Retrieve complete book catalog."""
        db = Database.get_db()
        if db is not None:
            return list(db.books.find({}, {"_id": 0}))
        return INITIAL_BOOKS

    @staticmethod
    def search_books(query):
        """
        Search books by Title, Author, or Category using case-insensitive regex query.
        """
        db = Database.get_db()
        query_str = query.strip()
        if db is not None:
            results = list(db.books.find({
                "$or": [
                    {"title": {"$regex": query_str, "$options": "i"}},
                    {"author": {"$regex": query_str, "$options": "i"}},
                    {"category": {"$regex": query_str, "$options": "i"}}
                ]
            }, {"_id": 0}))
            return results
        else:
            # Local search fallback
            q_lower = query_str.lower()
            return [b for b in INITIAL_BOOKS if q_lower in b['title'].lower() or q_lower in b['author'].lower() or q_lower in b['category'].lower()]

    @staticmethod
    def get_book_by_id(book_id):
        """Fetch single book record by ID."""
        db = Database.get_db()
        if db is not None:
            return db.books.find_one({"id": book_id}, {"_id": 0})
        return next((b for b in INITIAL_BOOKS if b["id"] == book_id), None)

    @staticmethod
    def add_book(book_data):
        """Add new book entry to library index vault."""
        db = Database.get_db()
        if db is not None:
            db.books.insert_one(book_data)
            return True
        INITIAL_BOOKS.append(book_data)
        return True

    @staticmethod
    def update_status(book_id, new_status):
        """Update status of a book (Available | Requested | Issued)."""
        db = Database.get_db()
        if db is not None:
            db.books.update_one({"id": book_id}, {"$set": {"status": new_status}})
        else:
            for b in INITIAL_BOOKS:
                if b["id"] == book_id:
                    b["status"] = new_status

    @staticmethod
    def get_counts():
        """Calculate counts for total, available, and issued books."""
        books = BookModel.get_all_books()
        total = len(books)
        available = sum(1 for b in books if b.get("status") == "Available")
        issued = sum(1 for b in books if b.get("status") == "Issued")
        return total, available, issued
