import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

class Config:
    """Flask application configuration class."""
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev_library_secret_key_12345')
    
    # MongoDB configuration
    MONGO_URI = os.environ.get('MONGO_URI', 'mongodb://localhost:27017/')
    DB_NAME = os.environ.get('DB_NAME', 'library_db')
    
    # Session configurations
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SECURE = False  # Set to True in production with HTTPS
    
    # Debug mode
    DEBUG = os.environ.get('FLASK_DEBUG', 'True') == 'True'
